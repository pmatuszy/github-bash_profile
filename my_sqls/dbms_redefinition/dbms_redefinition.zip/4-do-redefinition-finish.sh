sqlplus -S -L / as sysdba  @4-do-redefinition-finish.sql
